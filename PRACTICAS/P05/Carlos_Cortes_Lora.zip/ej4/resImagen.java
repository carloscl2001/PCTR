import java.util.*;

/**
 * Clase para realizar el resaltado de una imagen
 * @author Carlos Antonio Cortés Lora
 * @version concurrente
 */
public class resImagen {

    /**
     * Variable estatica para el tamaño de la matriz
     */
    public static int n = 9000;

    /**
     * Variable estatica para la matriz de entrada
     */
    public static int m[][] = new int[n][n];

    /**
     * Funcion para rellenar la matriz de forma aleatoria
     * @param m matriz 
     */
    public static void rellenarMatriz(int[][] m){
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[i].length; j++) {
                m[i][j] = (int)(Math.random()*255);
            }
        }
    }

    /**
     * Funcion para resaltar
     * @param m matriz
     */
    static public void resal(int m[][])
    {
        for(int i = 0; i < n; ++i){
            for(int j = 0; j < n; ++j)
            {
                m[i][j] =  4 * m[i][j];

                //Pixel de arriba
                if( i + 1 < n ){m[i][j] -= m[i + 1][j];}
                //Pixel de abajo
                if( i - 1 >= 0 ){m[i][j] -= m[i - 1][j];}
                //Pixel de la derecha
                if( j + 1 < n ){m[i][j] -= m[i][j + 1];}
                //Pixel de la izquierda
                if( j - 1 >= 0 ){m[i][j] -= m[i][j - 1];}
                
                m[i][j] /= 8;
            }
        }   
    }
    
   
    /**
     * Main del ejercicio
     * @param args
     */
    public static void main(String[] args) {
        rellenarMatriz(m);
        resal(m);
    }
}
